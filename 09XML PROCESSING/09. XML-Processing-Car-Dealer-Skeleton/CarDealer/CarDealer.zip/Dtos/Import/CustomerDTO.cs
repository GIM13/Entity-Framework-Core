﻿using System;

namespace CarDealer.DTO
{
    class CustomerDTO
    {
        public string Name { get; set; }

        public DateTime BirthDate { get; set; }

        public bool IsYoungDriver { get; set; }
    }
}
